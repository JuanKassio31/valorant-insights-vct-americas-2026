# Valorant Insights — VCT Americas Stage 2 2026

Projeto de portfólio de Juan Kassio: análise descritiva de resultados de séries, pipeline Python/SQLite e dashboard local interativo.

## Abrir agora
Requisito para o dashboard: Node.js 18 ou superior, sem dependências externas.

```sh
npm start
```

Abra http://127.0.0.1:8765. No VS Code: Terminal → Executar Tarefa → Abrir dashboard.

## Perguntas de negócio
- Quais equipes apresentam maior aproveitamento em cada fase?
- Como LOUD, MIBR e FURIA se comparam em vitórias e saldo de mapas?
- Qual é a frequência de séries vencidas sem perder mapa?
- Como o desempenho muda entre grupos, play-ins e playoffs?

## Dados reais e procedência
60 séries: 30 grupos, 18 play-ins, 12 playoffs. Consulta em 22/10/2026.
Fonte: VLR.gg, evento 2977, páginas de resultados por fase.
Dados transcritos e normalizados manualmente; cada linha tem source_url para auditoria.
URLs e limitações em data/metadata.json. Não há coleta automática nem dados simulados.
IDs locais identificam as linhas, não são IDs oficiais de partidas.
Ordem das linhas não deve ser interpretada como cronologia.
Datas omitidas porque a fonte consultada exibiu fusos diferentes entre páginas.

## Executar a análise em Python
Requisito: Python 3.10+. Não utiliza pip ou bibliotecas externas.

```sh
python scripts/analyze.py
```

O pipeline valida o CSV, carrega data/valorant.sqlite e gera reports/team_ranking.csv e reports/summary-python.json.
Pode ser reexecutado: recarrega a tabela dentro de uma transação, preservando integridade.
Pipeline Python executado e validado em 22/10/2026: 60 séries carregadas no SQLite e relatórios exportados.
O dashboard e os cálculos JavaScript têm execução e testes independentes.

## Validar e gerar resumo
```sh
npm test
npm run build
```

## Estrutura
- data/: CSV e JSON de séries, metadados e banco gerado pelo Python.
- scripts/analyze.py: carga, validação, SQLite e exportação.
- sql/: esquema, views e consultas comentadas.
- src/analytics.js: motor analítico do dashboard.
- public/: dashboard em português, filtros e tabelas.
- tests/: validação de placares e cálculos.
- reports/: resumos e análises exportadas.
- docs/: dicionário e roteiro para apresentar o projeto.

## Métricas
Aproveitamento de séries = vitórias / séries × 100.
Saldo de mapas = mapas ganhos − mapas perdidos.
Taxa de mapas = mapas ganhos / mapas disputados × 100.
Vitória sem ceder mapa = série cujo perdedor termina com zero mapas.
Filtros de equipe/fase atualizam todos os indicadores.
A busca textual afeta somente a tabela de resultados.

## Limites
Ranking por aproveitamento é analítico, não classificação oficial.
Não se pode inferir ACS, K/D, agentes, mapas específicos ou rounds a partir desses placares.
MD3 e MD5 têm pesos iguais no aproveitamento de séries e quantidades diferentes de mapas.
Amostras, fases e adversários diferentes exigem cuidado na comparação.
Este projeto independente não é afiliado à Riot Games ou ao VLR.gg.

