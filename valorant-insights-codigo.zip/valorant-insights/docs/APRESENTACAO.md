# Como apresentar o projeto em uma entrevista

1. Problema: entender o desempenho de equipes em um campeonato de Valorant com dados verificáveis.
2. Fonte: 60 resultados públicos com rastreabilidade por linha e escopo documentado.
3. Tratamento: normalização de nomes, validação de placares MD3/MD5 e identificadores únicos.
4. Armazenamento: SQLite com restrições e views para transformar séries em observações por equipe.
5. Análise: aproveitamento, vitórias, saldo de mapas e frequência de vitórias sem ceder mapa.
6. Visualização: dashboard com filtros por fase/equipe e tabelas auditáveis.
7. Limitações: ranking analítico não é classificação oficial; evitar comparar amostras muito diferentes.

Experimente filtrar playoffs e 100 Thieves. Depois compare LOUD, MIBR e FURIA.
Explique a diferença entre vencer uma série e vencer um mapa.
Como evolução, acrescente uma base de mapas e estatísticas de jogadores, com novas fontes verificadas.

Não afirme que usou pandas ou Power BI: esta versão usa biblioteca padrão Python, SQL e dashboard web.

