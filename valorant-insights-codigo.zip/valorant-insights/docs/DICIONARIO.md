# Dicionário de dados

Unidade: uma série concluída do VCT Americas Stage 2 2026.

| Coluna | Tipo | Significado |
|---|---|---|
| id | texto | Identificador local único |
| phase | texto | groups, playins ou playoffs |
| team_a / team_b | texto | Nomes normalizados das equipes |
| score_a / score_b | inteiro | Mapas vencidos na série |
| best_of | inteiro | 3 para MD3; 5 para MD5 |
| source_url | URL | Página da fase para conferir o resultado |

Não existem dados individuais de jogadores ou placares de rounds nesta base.
Uma série aparece uma vez em matches e duas vezes na view team_series (perspectiva de cada equipe).
Não some played entre equipes para obter o número de séries: isso duplica a contagem.

