"""Pipeline reproduzível: CSV -> validação -> SQLite -> consultas -> relatórios.
Somente biblioteca padrão. Execute: python scripts/analyze.py
"""
from pathlib import Path
import csv
import json
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
PHASES = {"groups", "playins", "playoffs"}

def load_matches(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError("Base vazia")
    ids = set()
    for row in rows:
        if not row["id"] or row["id"] in ids:
            raise ValueError("ID duplicado ou ausente")
        ids.add(row["id"])
        for key in ("score_a", "score_b", "best_of"):
            row[key] = int(row[key])
        a, b, bo = row["score_a"], row["score_b"], row["best_of"]
        if row["phase"] not in PHASES:
            raise ValueError("Fase inválida")
        if not row["team_a"] or not row["team_b"] or row["team_a"] == row["team_b"]:
            raise ValueError("Equipes inválidas")
        if bo not in (3, 5) or min(a, b) < 0 or max(a, b) != bo // 2 + 1 or a == b:
            raise ValueError("Placar inválido")
        if not row["source_url"].startswith("https://www.vlr.gg/"):
            raise ValueError("Fonte inválida")
    return rows

def main():
    rows = load_matches(ROOT / "data" / "matches.csv")
    target = ROOT / "reports"
    target.mkdir(exist_ok=True)
    db_path = ROOT / "data" / "valorant.sqlite"
    with sqlite3.connect(db_path) as con:
        con.row_factory = sqlite3.Row
        con.executescript((ROOT / "sql" / "schema.sql").read_text(encoding="utf-8"))
        with con:
            con.execute("DELETE FROM matches")
            con.executemany(
                """INSERT INTO matches
                (id,phase,team_a,team_b,score_a,score_b,best_of,source_url)
                VALUES (:id,:phase,:team_a,:team_b,:score_a,:score_b,:best_of,:source_url)""", rows)
        ranking = [dict(row) for row in con.execute(
            "SELECT * FROM team_ranking ORDER BY win_rate DESC,map_diff DESC,wins DESC,team")]
        with (target / "team_ranking.csv").open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=ranking[0].keys())
            writer.writeheader()
            writer.writerows(ranking)
        summary = dict(con.execute(
            """SELECT COUNT(*) AS series, SUM(score_a+score_b) AS maps,
            SUM(CASE WHEN MIN(score_a,score_b)=0 THEN 1 ELSE 0 END) AS sweeps
            FROM matches""").fetchone())
        summary["teams"] = len(ranking)
        summary["ranking"] = ranking
        (target / "summary-python.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"OK: {len(rows)} séries -> {db_path}")
    print("Relatórios disponíveis em reports/")

if __name__ == "__main__":
    main()

