const fs=require('fs'),path=require('path');
const {validate,analyze}=require('../src/analytics');
const matches=require('../data/matches.json');validate(matches);
fs.mkdirSync(path.join(__dirname,'../reports'),{recursive:true});
fs.writeFileSync(path.join(__dirname,'../reports/summary.json'),JSON.stringify(analyze(matches),null,2)+'\n');
console.log('Resumo gerado para '+matches.length+' séries.');

