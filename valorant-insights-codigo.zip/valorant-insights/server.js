'use strict';
const http=require('http'),fs=require('fs'),path=require('path');
const root=__dirname, port=Number(process.env.PORT||8765);
const routes={'/':'public/index.html','/app.js':'public/app.js','/style.css':'public/style.css','/analytics.js':'src/analytics.js','/data/matches.json':'data/matches.json','/data/matches.csv':'data/matches.csv','/data/metadata.json':'data/metadata.json'};
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.csv':'text/csv; charset=utf-8'};
const server=http.createServer((req,res)=>{
 const route=routes[req.url.split('?')[0]];
 if(!route){res.writeHead(404);return res.end('Não encontrado');}
 fs.readFile(path.join(root,route),(err,body)=>{if(err){res.writeHead(500);return res.end('Erro ao ler arquivo');}res.writeHead(200,{'Content-Type':types[path.extname(route)],'X-Content-Type-Options':'nosniff'});res.end(body);});
});
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'Porta ocupada. Defina PORT para usar outra porta.':e.message);process.exit(1)});
server.listen(port,'127.0.0.1',()=>console.log('Valorant Insights: http://127.0.0.1:'+port));

