-- Desempenho geral: não é classificação oficial.
SELECT * FROM team_ranking ORDER BY win_rate DESC,map_diff DESC;

-- Comparar equipes dentro de uma fase.
SELECT team, COUNT(*) AS series, SUM(win) AS wins,
 ROUND(100.0*SUM(win)/COUNT(*),2) AS win_rate
FROM team_series WHERE phase='playoffs'
GROUP BY team ORDER BY win_rate DESC;

-- Desempenho das equipes brasileiras: análise descritiva.
SELECT team,phase,COUNT(*) AS series,SUM(win) AS wins,
 SUM(maps_won)-SUM(maps_lost) AS map_diff
FROM team_series WHERE team IN ('LOUD','MIBR','FURIA','2Game Esports','Fluxo W7M')
GROUP BY team,phase;

-- Percentual de séries sem ceder mapa por fase.
SELECT phase,COUNT(*) AS series,
 ROUND(100.0*SUM(CASE WHEN MIN(score_a,score_b)=0 THEN 1 ELSE 0 END)/COUNT(*),2) AS sweep_rate
FROM matches GROUP BY phase;

-- Conferência: cada série gera uma vitória e uma derrota.
SELECT SUM(wins) AS total_wins,SUM(losses) AS total_losses FROM team_ranking;

