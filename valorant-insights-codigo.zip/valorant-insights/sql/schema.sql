CREATE TABLE IF NOT EXISTS matches (
 id TEXT PRIMARY KEY,
 phase TEXT NOT NULL CHECK(phase IN ('groups','playins','playoffs')),
 team_a TEXT NOT NULL,
 team_b TEXT NOT NULL CHECK(team_a<>team_b),
 score_a INTEGER NOT NULL CHECK(score_a>=0),
 score_b INTEGER NOT NULL CHECK(score_b>=0),
 best_of INTEGER NOT NULL CHECK(best_of IN (3,5)),
 source_url TEXT NOT NULL,
 CHECK((best_of=3 AND MAX(score_a,score_b)=2 AND MIN(score_a,score_b)<2)
 OR (best_of=5 AND MAX(score_a,score_b)=3 AND MIN(score_a,score_b)<3))
);
CREATE VIEW IF NOT EXISTS team_series AS
 SELECT id,phase,team_a AS team,team_b AS opponent,score_a AS maps_won,score_b AS maps_lost,
 CASE WHEN score_a>score_b THEN 1 ELSE 0 END AS win FROM matches
 UNION ALL
 SELECT id,phase,team_b,team_a,score_b,score_a,
 CASE WHEN score_b>score_a THEN 1 ELSE 0 END FROM matches;
CREATE VIEW IF NOT EXISTS team_ranking AS
 SELECT team,COUNT(*) AS played,SUM(win) AS wins,COUNT(*)-SUM(win) AS losses,
 SUM(maps_won) AS maps_won,SUM(maps_lost) AS maps_lost,
 SUM(maps_won)-SUM(maps_lost) AS map_diff,
 ROUND(100.0*SUM(win)/COUNT(*),2) AS win_rate,
 ROUND(100.0*SUM(maps_won)/SUM(maps_won+maps_lost),2) AS map_win_rate
 FROM team_series GROUP BY team;

