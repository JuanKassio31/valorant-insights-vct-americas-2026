const test=require('node:test'),assert=require('node:assert/strict');
const {validate,analyze}=require('../src/analytics'),matches=require('../data/matches.json');
test('base completa: fases, participantes e conservação de vitórias',()=>{
 assert.equal(validate(matches),true);assert.equal(matches.length,60);
 for(const [phase,n] of [['groups',30],['playins',18],['playoffs',12]])assert.equal(matches.filter(m=>m.phase===phase).length,n);
 const a=analyze(matches);assert.equal(a.teams,16);
 assert.equal(a.ranking.reduce((s,t)=>s+t.wins,0),60);
 assert.equal(a.ranking.reduce((s,t)=>s+t.losses,0),60);
 assert.equal(a.ranking.reduce((s,t)=>s+t.maps_won,0),a.maps);
});
test('MD3 e MD5 calculam séries e mapas separadamente',()=>{
 const rows=[{id:'a',phase:'playoffs',team_a:'A',team_b:'B',score_a:2,score_b:0,best_of:3},{id:'b',phase:'playoffs',team_a:'B',team_b:'A',score_a:3,score_b:2,best_of:5}];
 validate(rows);const a=analyze(rows),team=a.ranking.find(t=>t.team==='A');
 assert.equal(a.series,2);assert.equal(a.maps,7);assert.equal(a.sweeps,1);
 assert.equal(team.wins,1);assert.equal(team.map_diff,1);assert.equal(team.win_rate,50);
});
test('rejeita empate, placar incompleto, IDs repetidos e fase desconhecida',()=>{
 for(const change of [{score_a:1,score_b:1},{score_a:4},{phase:'invalid'},{team_b:matches[0].team_a}]){
  assert.throws(()=>validate([{...matches[0],...change}]));
 }
 assert.throws(()=>validate([matches[0],matches[0]]));
});
test('recorte vazio não gera NaN nem divisão por zero',()=>{
 assert.deepEqual(analyze([]),{series:0,maps:0,teams:0,sweeps:0,ranking:[]});
});
test('100 Thieves vence todas as suas séries de playoffs',()=>{
 const t=analyze(matches.filter(m=>m.phase==='playoffs')).ranking.find(t=>t.team==='100 Thieves');
 assert.equal(t.wins,3);assert.equal(t.losses,0);assert.equal(t.win_rate,100);
});

